# import sys
# import os

# # Add project root to path
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# import gym
# import numpy as np
# from gym import spaces
# from typing import List, Tuple

# from sim_core.flocking_controller import FlockingController
# from sim_core.formation_planner import FormationPlanner
# from sim_core.sensor_utils import get_range

# class DroneSwarmEnv(gym.Env):
#     metadata = {"render.modes": ["human"]}

#     def __init__(self,
#                  num_drones: int = 5,
#                  max_timesteps: int = 300,
#                  dt: float = 0.1,
#                  altitude: float = 10.0,
#                  max_force: float = 20.0,
#                  max_speed: float = 10.0,
#                  collision_threshold: float = 1.0,
#                  perception_radius: float = 50.0,
#                  horizontal_spacing: float = 20.0,
#                  vertical_spacing: float = 5.0,
#                  wind_ax: float = 0.002,
#                  wind_ay: float = 0.002,
#                  seed: int = None):

#         super(DroneSwarmEnv, self).__init__()

#         self.num_drones = num_drones
#         self.dt = dt
#         self.max_timesteps = max_timesteps
#         self.time_step = 0

#         self.altitude = altitude
#         self.max_force = max_force
#         self.max_speed = max_speed
#         self.collision_threshold = collision_threshold

#         self.perception_radius = perception_radius
#         self.horizontal_spacing = horizontal_spacing
#         self.vertical_spacing = vertical_spacing

#         self.wind_ax = wind_ax
#         self.wind_ay = wind_ay

#         self.seed_value = seed
#         if seed is not None:
#             self.seed(seed)

#         self.flock = FlockingController(
#             perception_radius=self.perception_radius,
#             max_speed=self.max_speed,
#             max_force=self.max_force,
#             weight_sep=4.0,
#             weight_align=1.0,
#             weight_cohesion=1.0,
#             weight_target=8.0,
#             kp_target=0.8,
#             nominal_spacing=5.0,
#             hover_slowing_radius=25.0,
#             vertical_hover_kp=20.0,
#             vertical_hover_kd=30.0
#         )

#         self.observation_space = spaces.Box(
#             low=-100.0,
#             high=100.0,
#             shape=(self.num_drones * 6,),
#             dtype=np.float32
#         )

#         self.action_space = spaces.Box(
#             low=-1.0,
#             high=1.0,
#             shape=(self.num_drones * 3,),
#             dtype=np.float32
#         )

#         self.reset()

#     def seed(self, seed=None):
#         np.random.seed(seed)

#     def reset(self):
#         self.positions = [
#             np.array([np.random.uniform(-70, 70), np.random.uniform(-70, 70), 1.0])
#             for _ in range(self.num_drones)
#         ]
#         self.velocities = [np.zeros(3) for _ in range(self.num_drones)]
#         self.imu_deltas = [np.zeros(3) for _ in range(self.num_drones)]
#         self.targets = FormationPlanner.staggered_pattern(
#             self.num_drones, self.horizontal_spacing, self.vertical_spacing, self.altitude)

#         self.time_step = 0
#         self.path_history = [[] for _ in range(self.num_drones)]  # for visualization
#         return self._get_obs()

#     def _get_obs(self):
#         return np.concatenate([np.concatenate((p, v)) for p, v in zip(self.positions, self.velocities)])

#     def step(self, action: np.ndarray):
#         forces = action.reshape((self.num_drones, 3)) * self.flock.max_force

#         new_velocities = []
#         new_positions = []
#         collisions = 0
#         total_dist = 0
#         total_speed = 0

#         for i in range(self.num_drones):
#             vx, vy, vz = self.velocities[i]
#             ax, ay, az = forces[i]

#             # Wind effect
#             ax += self.wind_ax
#             ay += self.wind_ay

#             drag = 0.005
#             ax -= drag * vx
#             ay -= drag * vy
#             az -= drag * vz

#             vx += ax * self.dt
#             vy += ay * self.dt
#             vz += az * self.dt

#             speed = np.linalg.norm([vx, vy, vz])
#             total_speed += speed
#             if speed > self.flock.max_speed:
#                 vx, vy, vz = (np.array([vx, vy, vz]) * (self.flock.max_speed / speed)).tolist()

#             px, py, pz = self.positions[i]
#             px += vx * self.dt
#             py += vy * self.dt
#             pz += vz * self.dt

#             new_positions.append(np.array([px, py, pz]))
#             new_velocities.append(np.array([vx, vy, vz]))
#             self.path_history[i].append([px, py, pz])  # save for path rendering

#         for i in range(self.num_drones):
#             for j in range(i + 1, self.num_drones):
#                 if np.linalg.norm(new_positions[i] - new_positions[j]) < self.collision_threshold:
#                     collisions += 1

#         reward = 0
#         reward -= collisions * 10

#         for i in range(self.num_drones):
#             dist = np.linalg.norm(new_positions[i] - np.array(self.targets[i]))
#             total_dist += dist
#             if dist < 1.0:
#                 reward += 2
#             if np.linalg.norm(new_velocities[i]) < 0.5 and dist < 1.5:
#                 reward += 3

#         reward -= 0.01 * total_dist
#         reward -= 0.005 * total_speed
#         reward -= 0.1

#         self.positions = new_positions
#         self.velocities = new_velocities
#         self.time_step += 1

#         done = self.time_step >= self.max_timesteps
#         return self._get_obs(), reward, done, {}

#     def render(self, mode="human"):
#         import matplotlib.pyplot as plt
#         from mpl_toolkits.mplot3d import Axes3D

#         fig = plt.figure(figsize=(10, 8))
#         ax = fig.add_subplot(111, projection='3d')

#         for i, path in enumerate(self.path_history):
#             path = np.array(path)
#             if len(path) > 0:
#                 ax.plot(path[:, 0], path[:, 1], path[:, 2], label=f"Drone {i}")
#                 ax.scatter(*self.targets[i], color='red', marker='x', s=100)
#                 ax.scatter(*path[-1], color='blue')

#         ax.set_xlim(-100, 100)
#         ax.set_ylim(-100, 100)
#         ax.set_zlim(0, self.altitude + 10)
#         ax.set_xlabel('X')
#         ax.set_ylabel('Y')
#         ax.set_zlabel('Z')
#         ax.set_title("Drone Swarm 3D Trajectories")
#         ax.legend()
#         plt.show()

import matplotlib
matplotlib.use('TkAgg') # Or 'QtAgg' if you prefer and have it installed

import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from mpl_toolkits.mplot3d import Axes3D
from stable_baselines3 import PPO

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from models.drone_swarm_env import DroneSwarmEnv


def run_visualization(history, targets, target_altitude):
    # print(f"run_visualization: Starting with {len(history)} frames.") # Removed debug print
    if not history:
        print("run_visualization: History is empty, no animation will be shown.")
        return # Exit if no history to animate

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    scat = ax.scatter([], [], [], s=80, c='blue', label='Drones')

    txs = [t[0] for t in targets]
    tys = [t[1] for t in targets]
    tzs = [t[2] for t in targets]
    ax.scatter(txs, tys, tzs, s=100, c='red', marker='X', label='Targets') # Displays targets

    ax.view_init(elev=20, azim=180)

    # Calculate limits based on history and targets
    all_xs = [pos[0] for frame in history for pos in frame]
    all_ys = [pos[1] for frame in history for pos in frame]
    all_zs = [pos[2] for frame in history for pos in frame]

    all_xs.extend(txs)
    all_ys.extend(tys)
    all_zs.extend(tzs)

    if all_xs: # Ensure there's data before setting limits
        ax.set_xlim(min(all_xs) - 10, max(all_xs) + 10)
        ax.set_ylim(min(all_ys) - 10, max(all_ys) + 10)
        ax.set_zlim(min(min(all_zs), 0.0) - 1, max(max(all_zs), target_altitude + 5) + 1)
    else: # Fallback limits if no data
        ax.set_xlim(-100, 100)
        ax.set_ylim(-100, 100)
        ax.set_zlim(0, target_altitude + 10)

    ax.set_title("Drone Swarm - Trained PPO Model")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.legend()
    ax.grid(True)

    def update(frame):
        coords = history[frame]
        xs = [x for x, y, z in coords]
        ys = [y for x, y, z in coords]
        zs = [z for x, y, z in coords]
        scat._offsets3d = (xs, ys, zs)
        return scat,

    # print("run_visualization: Creating FuncAnimation...") # Removed debug print
    ani = animation.FuncAnimation(fig, update, frames=len(history), interval=50, blit=False)
    
    # print("run_visualization: Calling plt.show()... (Window should appear and block script)") # Removed debug print
    plt.show()
    # print("run_visualization: plt.show() returned. (Window was closed by user)") # Removed debug print


def simulate_trained_model(model_path: str, num_steps: int = 300):
    # print("simulate_trained_model: Starting simulation setup.") # Removed debug print
    env = DroneSwarmEnv(num_drones=7, max_timesteps=num_steps, target_altitude=10.0) 
    
    obs, info = env.reset() 
    # print("simulate_trained_model: Environment reset. Loading model...") # Removed debug print

    model = PPO.load(model_path)
    # print("simulate_trained_model: Model loaded. Starting simulation loop...") # Removed debug print

    history = []
    targets = env.targets 

    for i in range(num_steps): 
        action, _states = model.predict(obs, deterministic=True)
        
        obs, reward, terminated, truncated, info = env.step(action) 
        
        history.append([pos.copy() for pos in env.positions])

        # if i % 50 == 0: # Removed debug print
        #     if env.positions: # Removed debug print
        #         print(f"simulate_trained_model: Step {i}: First drone at {env.positions[0]}") # Removed debug print
        #     else: # Removed debug print
        #         print(f"simulate_trained_model: Step {i}: env.positions is empty.") # Removed debug print

        if terminated or truncated:
            # print(f"simulate_trained_model: Episode finished after {env.current_timestep} timesteps.") # Removed debug print
            break
    
    # print(f"simulate_trained_model: Simulation loop finished. Total timesteps simulated: {env.current_timestep}. Raw history length: {len(history)}") # Removed debug print
    # if not history: # Removed debug print
    #     print("simulate_trained_model: WARNING: History is empty! No drone positions recorded during simulation.") # Removed debug print
    # elif len(history) == 1: # Removed debug print
    #     print("simulate_trained_model: WARNING: History contains only 1 frame. Animation will be static.") # Removed debug print

    # print("simulate_trained_model: Calling run_visualization...") # Removed debug print
    run_visualization(history, targets, target_altitude=env.altitude)
    # print("simulate_trained_model: Script finished.") # Removed debug print


if __name__ == "__main__":
    model_path = os.path.join("models", "ppo_drone_swarm.zip")
    
    if not os.path.exists(model_path):
        print(f"Error: Model file not found at {model_path}")
        print("Please ensure you have trained a model and it's saved at this location.")
        sys.exit(1)

    simulate_trained_model(model_path)