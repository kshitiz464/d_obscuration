# import gym
# import numpy as np
# from gym import spaces

# class DroneSwarmEnv(gym.Env):
#     def __init__(self,
#                  num_drones=5,
#                  max_timesteps=300,
#                  dt=0.1,
#                  altitude=10.0,
#                  max_force=20.0,
#                  max_speed=10.0,
#                  collision_threshold=1.0,
#                  perception_radius=50.0,
#                  horizontal_spacing=20.0,
#                  vertical_spacing=5.0,
#                  wind_ax=0.002,
#                  wind_ay=0.002,
#                  seed=None):
#         super(DroneSwarmEnv, self).__init__()

#         self.num_drones = num_drones
#         self.max_timesteps = max_timesteps
#         self.dt = dt
#         self.altitude = altitude
#         self.max_force = max_force
#         self.max_speed = max_speed
#         self.collision_threshold = collision_threshold
#         self.perception_radius = perception_radius
#         self.horizontal_spacing = horizontal_spacing
#         self.vertical_spacing = vertical_spacing
#         self.wind_ax = wind_ax
#         self.wind_ay = wind_ay

#         self.seed(seed)

#         # Observation: position and velocity of all drones and their targets
#         obs_dim = self.num_drones * 6  # 3D position + 3D velocity
#         self.observation_space = spaces.Box(low=-100.0, high=100.0, shape=(obs_dim,), dtype=np.float32)

#         # Action: acceleration in 3D for each drone
#         self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(self.num_drones * 3,), dtype=np.float32)

#         self.reset()

#     def reset(self):
#         self.timestep = 0
#         self.drones = []
#         self.targets = []
#         self.prev_positions = []

#         for i in range(self.num_drones):
#             pos = np.array([i * self.horizontal_spacing, 0.0, self.altitude])
#             vel = np.zeros(3)
#             self.drones.append({"position": pos.copy(), "velocity": vel.copy()})
#             self.targets.append(pos + np.array([0.0, 50.0, 0.0]))
#             self.prev_positions.append(pos.copy())

#         return self._get_obs()

#     def step(self, action):
#         action = action.reshape((self.num_drones, 3))
#         rewards = 0.0
#         done = False

#         for i in range(self.num_drones):
#             acc = np.clip(action[i], -1.0, 1.0) * self.max_force
#             acc[0] += self.wind_ax  # wind effect
#             acc[1] += self.wind_ay

#             drone = self.drones[i]
#             drone["velocity"] += acc * self.dt
#             speed = np.linalg.norm(drone["velocity"])
#             if speed > self.max_speed:
#                 drone["velocity"] = drone["velocity"] / speed * self.max_speed

#             drone["position"] += drone["velocity"] * self.dt

#         # Enhanced reward structure
#         for i in range(self.num_drones):
#             current_dist = np.linalg.norm(self.drones[i]["position"] - self.targets[i])
#             prev_dist = np.linalg.norm(self.prev_positions[i] - self.targets[i])
#             rewards += (prev_dist - current_dist) * 10

#             if current_dist < 2.0:
#                 rewards += 50

#             self.prev_positions[i] = self.drones[i]["position"].copy()

#         for i in range(self.num_drones):
#             for j in range(i + 1, self.num_drones):
#                 dist = np.linalg.norm(self.drones[i]["position"] - self.drones[j]["position"])
#                 if dist < self.collision_threshold:
#                     rewards -= 100

#         rewards -= 0.01  # time penalty
#         rewards = np.clip(rewards, -200, 200)

#         self.timestep += 1
#         done = self.timestep >= self.max_timesteps

#         return self._get_obs(), rewards, done, {}

#     def _get_obs(self):
#         obs = []
#         for drone in self.drones:
#             obs.extend(drone["position"])
#             obs.extend(drone["velocity"])
#         return np.array(obs, dtype=np.float32)

#     def render(self, mode="human"):
#         pass  # Optional: add visualization logic if needed

#     def seed(self, seed=None):
#         np.random.seed(seed)


import gymnasium as gym
from gymnasium import spaces
import numpy as np

class Drone:
    def __init__(self, initial_position, initial_velocity=None):
        self.position = np.array(initial_position, dtype=np.float32)
        self.velocity = np.array(initial_velocity if initial_velocity is not None else [0.0, 0.0, 0.0], dtype=np.float32)

    def update_state(self, action, time_step=0.1, max_speed=5.0):
        self.velocity += action # action represents change in velocity (simplistic force/acceleration)
        self.velocity = np.clip(self.velocity, -max_speed, max_speed) # Cap velocity
        self.position += self.velocity * time_step

        self.position[2] = max(self.position[2], 0.0) # Ensure Z doesn't go below ground

class DroneSwarmEnv(gym.Env):
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 30}

    def __init__(self, num_drones: int = 7, max_timesteps: int = 300,
                 dt: float = 0.1, target_altitude: float = 10.0,
                 max_force: float = 20.0, max_speed: float = 10.0,
                 collision_threshold: float = 1.0, perception_radius: float = 50.0,
                 horizontal_spacing: float = 20.0, vertical_spacing: float = 5.0,
                 wind_ax: float = 0.0, wind_ay: float = 0.0, seed: int = None,
                 target_tolerance: float = 2.0):

        super(DroneSwarmEnv, self).__init__()

        self.num_drones = num_drones
        self.max_timesteps = max_timesteps
        self.dt = dt
        self.target_altitude = target_altitude
        self.max_force = max_force
        self.max_speed = max_speed
        self.collision_threshold = collision_threshold
        self.perception_radius = perception_radius # Currently not used in observation or reward, but stored.
        self.horizontal_spacing = horizontal_spacing
        self.vertical_spacing = vertical_spacing
        self.wind_ax = wind_ax
        self.wind_ay = wind_ay
        self.seed = seed
        self.target_tolerance = target_tolerance

        # Set random seed for initial states (if reset does not handle it)
        if self.seed is not None:
            np.random.seed(self.seed)

        self.targets_list = self._generate_targets()

        # --- OBSERVATION SPACE DEFINITION ---
        # All drone states (num_drones * 6) + All target states (num_drones * 3)
        # Low/high bounds for drone state (x,y,z, vx,vy,vz)
        low_drone_state = np.array([-100.0, -100.0, 0.0,   -self.max_speed, -self.max_speed, -self.max_speed], dtype=np.float32)
        high_drone_state = np.array([100.0, 100.0, 50.0,    self.max_speed, self.max_speed, self.max_speed], dtype=np.float32)

        # Low/high bounds for target state (x,y,z)
        low_target_state = np.array([-100.0, -100.0, 0.0], dtype=np.float32)
        high_target_state = np.array([100.0, 100.0, 50.0], dtype=np.float32)

        low_obs_full = np.concatenate((
            np.tile(low_drone_state, self.num_drones),
            np.tile(low_target_state, self.num_drones)
        ))
        high_obs_full = np.concatenate((
            np.tile(high_drone_state, self.num_drones),
            np.tile(high_target_state, self.num_drones)
        ))

        self.observation_space = spaces.Box(low=low_obs_full, high=high_obs_full, dtype=np.float32)

        # --- ACTION SPACE DEFINITION ---
        # Action space for each drone (3D force vector / change in velocity)
        low_action = np.array([-self.max_force, -self.max_force, -self.max_force] * self.num_drones, dtype=np.float32)
        high_action = np.array([self.max_force, self.max_force, self.max_force] * self.num_drones, dtype=np.float32)
        self.action_space = spaces.Box(low=low_action, high=high_action, dtype=np.float32)

        self.drones = []
        self.positions = []

        self.reset()

    def _generate_targets(self):
        # Fixed zig-zag pattern using horizontal_spacing and vertical_spacing
        x_spacing = self.horizontal_spacing
        y_zigzag_offset = self.vertical_spacing

        targets = []
        for i in range(self.num_drones):
            x = i * x_spacing
            y = 0.0
            if i % 2 != 0: # Odd-indexed targets go to offset Y
                y = y_zigzag_offset
            z = self.target_altitude # Targets at specified altitude

            targets.append(np.array([x, y, z], dtype=np.float32))

        return targets

    @property
    def targets(self):
        return self.targets_list

    @property
    def altitude(self):
        return self.target_altitude

    def _get_obs(self):
        drone_states = []
        for drone in self.drones:
            drone_states.extend(drone.position.tolist())
            drone_states.extend(drone.velocity.tolist())

        target_states_flat = []
        for target in self.targets_list:
            target_states_flat.extend(target.tolist())

        # Concatenate drone states and target states
        observation = np.array(drone_states + target_states_flat, dtype=np.float32)
        return observation

    def reset(self, seed=None, options=None):
        super().reset(seed=seed) # Important for Gymnasium seeding for reproducibility

        # Apply internal seed if provided, for initial drone states randomness
        if self.seed is not None:
             np.random.seed(self.seed)

        self.current_timestep = 0

        self.drones = []
        self.positions = []

        for i in range(self.num_drones):
            # Drones start from random positions near ground
            initial_pos = np.array([np.random.uniform(-5, 5), np.random.uniform(-5, 5), np.random.uniform(0.1, 1.0)], dtype=np.float32)
            initial_vel = np.array([np.random.uniform(-0.5, 0.5), np.random.uniform(-0.5, 0.5), np.random.uniform(0.0, 0.2)], dtype=np.float32)
            drone = Drone(initial_pos, initial_vel)
            self.drones.append(drone)
            self.positions.append(drone.position.copy())

        observation = self._get_obs()
        info = {}

        return observation, info

    def step(self, action):
        self.current_timestep += 1

        # Apply wind effect (simple constant wind)
        wind_effect = np.array([self.wind_ax, self.wind_ay, 0.0], dtype=np.float32)

        reshaped_action = action.reshape(self.num_drones, 3)

        for i, drone in enumerate(self.drones):
            # Apply action and wind effect
            effective_action = reshaped_action[i] + wind_effect # Simplistic addition
            drone.update_state(effective_action, time_step=self.dt, max_speed=self.max_speed)
            self.positions[i] = drone.position.copy()

        observation = self._get_obs()

        reward = 0.0

        # Ensure num_drones matches number of targets for this reward strategy
        if self.num_drones != len(self.targets_list):
            raise ValueError("Number of drones must match number of targets for this specific reward function strategy.")

        for i in range(self.num_drones):
            drone_pos = self.positions[i]
            target_pos = self.targets_list[i]

            distance_to_target = np.linalg.norm(drone_pos - target_pos)

            # 1. Penalty for overall distance to assigned target
            reward -= distance_to_target * 0.1

            # 2. Stronger reward/bonus for being within target tolerance
            if distance_to_target < self.target_tolerance:
                reward += 1.0 # Bonus for being "at" the target

                # Further reward for low velocity when at target (hovering)
                drone_vel = self.drones[i].velocity
                speed = np.linalg.norm(drone_vel)
                reward -= speed * 0.05 # Penalize high speed when near target

            # --- NEW: 3. Penalty for altitude deviation from target altitude ---
            altitude_deviation = abs(drone_pos[2] - target_pos[2]) # deviation from individual target's Z
            reward -= altitude_deviation * 0.2 # Increased penalty for altitude error (tune this value)

            # --- NEW: 4. Strong penalty for being too close to the ground ---
            if drone_pos[2] < 0.5: # If drone is very close to the ground (e.g., within 0.5m)
                reward -= 5.0 # Significant penalty to discourage hitting the ground

            # 5. Penalize collisions between drones
            for j in range(i + 1, self.num_drones):
                other_drone_pos = self.positions[j]
                dist_between_drones = np.linalg.norm(drone_pos - other_drone_pos)
                if dist_between_drones < self.collision_threshold:
                    reward -= (self.collision_threshold - dist_between_drones) * 2.0 # Stronger penalty for collision

        terminated = self.current_timestep >= self.max_timesteps
        truncated = False

        info = {}

        return observation, reward, terminated, truncated, info