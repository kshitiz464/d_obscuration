from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import CheckpointCallback, EvalCallback
import sys
import os
import time # Import time to measure training duration

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Import the updated DroneSwarmEnv
from models.drone_swarm_env import DroneSwarmEnv

def main():
    # Custom environment settings - ADDED target_tolerance
    env_kwargs = {
        "num_drones": 7,
        "max_timesteps": 300,
        "dt": 0.1, # Your existing dt
        "target_altitude": 10.0, # Renamed from 'altitude' to match env constructor
        "max_force": 20.0,
        "max_speed": 10.0,
        "collision_threshold": 1.0,
        "perception_radius": 50.0, # Your existing perception_radius
        # "horizontal_spacing": 20.0, # These are likely for specific target generation,
        # "vertical_spacing": 5.0,    # if you use custom target generation in _generate_targets, keep them.
                                    # But for the fixed zig-zag, they aren't directly used by the env init.
        "wind_ax": 0.002, 
        "wind_ay": 0.002,
        "seed": 42,
        "target_tolerance": 2.0 # ADDED: Crucial for the new reward function
    }

    # Create vectorized training and evaluation environments
    # Use lambda to correctly pass env_kwargs to the environment constructor
    env = make_vec_env(lambda: DroneSwarmEnv(**env_kwargs), n_envs=4)
    eval_env = make_vec_env(lambda: DroneSwarmEnv(**env_kwargs), n_envs=1)

    # Set up callbacks
    checkpoint_callback = CheckpointCallback(
        save_freq=100_000,
        save_path="./models/checkpoints/",
        name_prefix="ppo_drone_swarm"
    )

    eval_callback = EvalCallback(
        eval_env,
        best_model_save_path="./models/best_model/",
        log_path="./models/eval_logs/",
        eval_freq=20_000,
        deterministic=True,
        render=False
    )

    # Define PPO model
    model = PPO(
        policy="MlpPolicy",
        env=env,
        verbose=1,
        tensorboard_log="./ppo_drone_tensorboard/",
        learning_rate=3e-4,
        n_steps=2048,
        batch_size=64,
        gae_lambda=0.95,
        gamma=0.99,
        ent_coef=0.02,
        vf_coef=0.5,
        max_grad_norm=0.5,
        # policy_kwargs=dict(net_arch=[dict(pi=[64, 64], vf=[64, 64])]) # Example: uncomment if you want a specific network architecture
    )

    # Total training timesteps
    TOTAL_TIMESTEPS = 5_000_000 # Your existing value, good for starting. Consider increasing it later.

    print(f"Starting training for {TOTAL_TIMESTEPS} timesteps...")
    start_time = time.time() # Start timer

    try:
        # Begin training with callbacks
        model.learn(
            total_timesteps=TOTAL_TIMESTEPS,
            callback=[checkpoint_callback, eval_callback],
            progress_bar=True # Added progress bar for better visualization
        )
    except KeyboardInterrupt:
        print("Training manually interrupted. Saving model...")
        model.save("models/ppo_drone_swarm_interrupted")
        print("Model saved as 'ppo_drone_swarm_interrupted'.")
        return

    end_time = time.time() # End timer
    print(f"Training finished in {end_time - start_time:.2f} seconds.") # Print duration

    # Save final model
    model.save("models/ppo_drone_swarm") # This will overwrite your existing ppo_drone_swarm.zip
    print("Model training complete and saved.")

    # Close the environments
    env.close()
    eval_env.close()
    print("Environments closed.")

if __name__ == "__main__":
    main()



# from stable_baselines3 import PPO
# from stable_baselines3.common.env_util import make_vec_env
# from stable_baselines3.common.callbacks import CheckpointCallback, EvalCallback
# import sys
# import os

# # Add project root to path
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# from models.drone_swarm_env import DroneSwarmEnv

# def main():
#     # Custom environment settings
#     env_kwargs = {
#         "num_drones": 7,
#         "max_timesteps": 300,
#         "dt": 0.1,
#         "altitude": 10.0,
#         "max_force": 20.0,
#         "max_speed": 10.0,
#         "collision_threshold": 1.0,
#         "perception_radius": 50.0,
#         "horizontal_spacing": 20.0,
#         "vertical_spacing": 5.0,
#         "wind_ax": 0.002,       # further reduced wind effect
#         "wind_ay": 0.002,
#         "seed": 42
#     }

#     # Create vectorized training and evaluation environments
#     env = make_vec_env(lambda: DroneSwarmEnv(**env_kwargs), n_envs=4)
#     eval_env = make_vec_env(lambda: DroneSwarmEnv(**env_kwargs), n_envs=1)

#     # Set up callbacks
#     checkpoint_callback = CheckpointCallback(
#         save_freq=100_000,
#         save_path="./models/checkpoints/",
#         name_prefix="ppo_drone_swarm"
#     )

#     eval_callback = EvalCallback(
#         eval_env,
#         best_model_save_path="./models/best_model/",
#         log_path="./models/eval_logs/",
#         eval_freq=20_000,
#         deterministic=True,
#         render=False
#     )

#     # Define PPO model
#     model = PPO(
#         policy="MlpPolicy",
#         env=env,
#         verbose=1,
#         tensorboard_log="./ppo_drone_tensorboard/",
#         learning_rate=3e-4,
#         n_steps=2048,
#         batch_size=64,
#         gae_lambda=0.95,
#         gamma=0.99,
#         ent_coef=0.02,  # slightly increased to encourage better exploration
#         vf_coef=0.5,
#         max_grad_norm=0.5,
#     )

#     try:
#         # Begin training with callbacks
#         model.learn(
#             total_timesteps=1_000_000,  # longer training duration
#             callback=[checkpoint_callback, eval_callback]
#         )
#     except KeyboardInterrupt:
#         print("🛑 Training manually interrupted. Saving model...")
#         model.save("models/ppo_drone_swarm_interrupted")
#         print("💾 Model saved as 'ppo_drone_swarm_interrupted'.")
#         return

#     # Save final model
#     model.save("models/ppo_drone_swarm")
#     print("✅ Model training complete and saved.")

# if __name__ == "__main__":
#     main()
